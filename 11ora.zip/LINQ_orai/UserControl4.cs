﻿using LINQ_orai.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_orai
{
    public partial class UserControl4 : UserControl
    {
        

        StudiesContext context = new StudiesContext();
    
        public UserControl4()
        {
            InitializeComponent();
            var adatok = from i in context.Courses
                         select new
                         {
                             Kurzus = i.CourseSk,
                             Nev = i.Name,
                             Kod = i.Code,
                             Lesson = i.Lessons
                         };



            dataGridView1.DataSource = adatok.ToList();

        }


    }
}
