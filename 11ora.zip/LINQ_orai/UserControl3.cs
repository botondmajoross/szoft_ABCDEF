﻿using CsvHelper;
using LINQ_orai.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_orai
{
    public partial class UserControl3 : UserControl
    {
        StudiesContext context = new StudiesContext();
        public UserControl3()
        {
            InitializeComponent();

             var lista = (from i in context.Instructors
                                        select new
                                        {
                                            Instr = i.InstructorSk,
                                            Salut = i.Salutation,
                                            Namee = i.Name,
                                            Stat = i.StatusFkNavigation.Name,
                                            Emp = i.EmployementFkNavigation.Name
                                        }).ToList();
            dataGridView1.DataSource = lista;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var writer = new StreamWriter("Oktatok.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                // Write records to the CSV file
                csv.WriteRecords(dataGridView1.DataSource as IEnumerable<object>);
            };
        }
    }
}
