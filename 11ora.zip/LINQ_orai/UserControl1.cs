﻿using LINQ_orai.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_orai
{
    public partial class UserControl1 : UserControl
    {
        Models.StudiesContext context = new();
        public UserControl1()
        {
            InitializeComponent();

            FillDataSource();

            ListBoxFeltoltes();


        }
        private void ListBoxFeltoltes()
        {

            var ilist = from i in context.Instructors
                        select i;
            listBox1.DataSource = ilist.ToList();
            listBox1.DisplayMember = "Name";
           
        }

        private void FillDataSource()
        {
            listBox1.DataSource = (from x in context.Instructors
                                   where x.Name.StartsWith(textBox1.Text)
                                   select x).ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillDataSource();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
          
        {
            if (listBox1.SelectedItem == null) return ;
            Instructor selectedInstructor = listBox1.SelectedItem as Instructor;

            var orak = from l in context.Lessons
                       where l.InstructorFk == selectedInstructor.InstructorSk
                       select new
                       {
                           Kurzus = l.CourseFkNavigation.Name,
                           Nap = l.DayFkNavigation.Name,
                           Sáv = l.TimeFkNavigation.Name
                       };
            dataGridView1.DataSource = orak.ToList();
        }
        
    }
}
