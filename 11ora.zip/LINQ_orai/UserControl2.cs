﻿using LINQ_orai.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_orai
{
    public partial class UserControl2 : UserControl
    {
        StudiesContext context = new StudiesContext();
        public UserControl2()
        {
            InitializeComponent();

            ListBoxFeltoltes();

            FillDataSource();
        }
        private void ListBoxFeltoltes()
        {
            listBox1.DataSource = (from i in context.Courses
                                   select i).ToList();
            listBox1.DisplayMember = ("Name");
        }
        private void FillDataSource()
        {
            listBox1.DataSource = (from i in context.Courses
                                   where i.Name.StartsWith(textBox1.Text)
                                   select i).ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillDataSource();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Course selectedCourse = listBox1.SelectedItem as Course;
            dataGridView1.DataSource = (from l in context.Lessons
                                        where l.CourseFk == selectedCourse.CourseSk
                                        select new
                                        {
                                            ora = l.CourseFkNavigation.Name,
                                            nap = l.DayFkNavigation.Name,
                                            oktato = l.InstructorFkNavigation.Name,
                                        }).ToList();
            
        }


        
    }
}
