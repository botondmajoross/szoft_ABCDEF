using SQL_Csat.Models;

namespace SQL_Csat
{
    public partial class Form1 : Form
    {
        Models.StudentContext studentContext = new Models.StudentContext();
        public Form1()
        {
            InitializeComponent();
            //dataGridView1.DataSource = studentContext.Students.ToList();
            studentBindingSource.DataSource = studentContext.Students.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                studentContext.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.InnerException.Message);
            }
        }
    }
}
